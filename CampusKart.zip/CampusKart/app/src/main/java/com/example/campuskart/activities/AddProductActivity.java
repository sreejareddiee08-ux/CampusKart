
package com.example.campuskart.activities;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.campuskart.R;
import com.example.campuskart.models.Product;
import com.example.campuskart.repositories.ProductRepository;
import com.example.campuskart.utils.Constants;
import com.example.campuskart.utils.ValidationUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AddProductActivity extends AppCompatActivity {

    private EditText etTitle;
    private EditText etPrice;
    private EditText etDescription;

    private Spinner spCategory;
    private Spinner spCondition;

    private TextView tvSelectedImage;
    private Button btnChooseImage;
    private Button btnSaveProduct;

    private Uri selectedImageUri;

    private ProductRepository productRepository;
    private FirebaseAuth firebaseAuth;

    private final Handler saveHandler =
            new Handler(Looper.getMainLooper());

    private Runnable timeoutRunnable;

    private final ActivityResultLauncher<String> imagePicker =
            registerForActivityResult(
                    new ActivityResultContracts.GetContent(),
                    uri -> {
                        if (uri != null) {
                            selectedImageUri = uri;
                            tvSelectedImage.setText(
                                    "Image selected: "
                                            + uri.getLastPathSegment()
                            );
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        etTitle = findViewById(R.id.etProductTitle);
        etPrice = findViewById(R.id.etProductPrice);
        etDescription = findViewById(R.id.etProductDescription);

        spCategory = findViewById(R.id.spProductCategory);
        spCondition = findViewById(R.id.spProductCondition);

        tvSelectedImage = findViewById(R.id.tvSelectedImage);
        btnChooseImage = findViewById(R.id.btnChooseImage);
        btnSaveProduct = findViewById(R.id.btnSaveProduct);

        firebaseAuth = FirebaseAuth.getInstance();
        productRepository = new ProductRepository();

        setupSpinners();

        btnChooseImage.setOnClickListener(view ->
                imagePicker.launch("image/*")
        );

        btnSaveProduct.setOnClickListener(view ->
                saveProduct()
        );
    }

    private void setupSpinners() {
        ArrayAdapter<String> categoryAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        Constants.PRODUCT_CATEGORIES
                );

        categoryAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        spCategory.setAdapter(categoryAdapter);

        ArrayAdapter<String> conditionAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        Constants.PRODUCT_CONDITIONS
                );

        conditionAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        spCondition.setAdapter(conditionAdapter);
    }

    private void saveProduct() {
        String title = etTitle.getText().toString().trim();
        String priceText = etPrice.getText().toString().trim();
        String description =
                etDescription.getText().toString().trim();

        if (!ValidationUtils.isValidProductTitle(title)) {
            etTitle.setError("Enter a valid product title");
            etTitle.requestFocus();
            return;
        }

        if (!ValidationUtils.isValidPrice(priceText)) {
            etPrice.setError("Enter a valid price");
            etPrice.requestFocus();
            return;
        }

        if (!ValidationUtils.isValidDescription(description)) {
            etDescription.setError("Enter a valid description");
            etDescription.requestFocus();
            return;
        }

        FirebaseUser user = firebaseAuth.getCurrentUser();

        if (user == null) {
            Toast.makeText(
                    this,
                    "Please log in before adding a product.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        if (spCategory.getSelectedItem() == null
                || spCondition.getSelectedItem() == null) {
            Toast.makeText(
                    this,
                    "Please select a category and condition.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        double price;

        try {
            price = Double.parseDouble(priceText);

            if (!Double.isFinite(price) || price <= 0) {
                etPrice.setError("Price must be greater than zero");
                etPrice.requestFocus();
                return;
            }
        } catch (NumberFormatException exception) {
            etPrice.setError("Enter a valid price");
            etPrice.requestFocus();
            return;
        }

        String category = spCategory.getSelectedItem().toString();
        String condition = spCondition.getSelectedItem().toString();

        String email = user.getEmail() == null
                ? ""
                : user.getEmail();

        String sellerName = email.contains("@")
                ? email.substring(0, email.indexOf("@"))
                : "CampusKart Student";

        Product product = new Product(
                null,
                title,
                description,
                category,
                condition,
                sellerName,
                email,
                price
        );

        btnSaveProduct.setEnabled(false);
        btnSaveProduct.setText("Saving...");

        timeoutRunnable = () -> {
            btnSaveProduct.setEnabled(true);
            btnSaveProduct.setText("Save Product");

            Toast.makeText(
                    AddProductActivity.this,
                    "No response from Firestore. Check your connection, database, and security rules.",
                    Toast.LENGTH_LONG
            ).show();
        };

        saveHandler.postDelayed(timeoutRunnable, 15000);

        productRepository.saveProduct(
                product,
                user.getUid(),
                new ProductRepository.ProductCallback() {

                    @Override
                    public void onSuccess(String productId) {
                        saveHandler.removeCallbacks(timeoutRunnable);

                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        Toast.makeText(
                                AddProductActivity.this,
                                "Product listed successfully!",
                                Toast.LENGTH_LONG
                        ).show();

                        finish();
                    }

                    @Override
                    public void onFailure(String error) {
                        saveHandler.removeCallbacks(timeoutRunnable);

                        if (isFinishing() || isDestroyed()) {
                            return;
                        }

                        btnSaveProduct.setEnabled(true);
                        btnSaveProduct.setText("Save Product");

                        Toast.makeText(
                                AddProductActivity.this,
                                "Could not save product: " + error,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );
    }

    @Override
    protected void onDestroy() {
        saveHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
