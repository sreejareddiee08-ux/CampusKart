
package com.example.campuskart.models;

public class Category {

    private String categoryId;
    private String categoryName;
    private int iconResource;

    public Category() {
    }

    public Category(String categoryId, String categoryName, int iconResource) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.iconResource = iconResource;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public int getIconResource() {
        return iconResource;
    }

    public void setIconResource(int iconResource) {
        this.iconResource = iconResource;
    }
}
