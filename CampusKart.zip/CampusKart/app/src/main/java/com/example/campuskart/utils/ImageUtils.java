
package com.example.campuskart.utils;

import android.net.Uri;

public final class ImageUtils {

    private ImageUtils() {
        // Prevent object creation
    }

    public static boolean isValidImageUri(Uri imageUri) {
        return imageUri != null
                && imageUri.getScheme() != null
                && ("content".equals(imageUri.getScheme())
                || "file".equals(imageUri.getScheme()));
    }
}
