
package com.example.campuskart.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.models.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WishlistAdapter
        extends RecyclerView.Adapter<WishlistAdapter.WishlistViewHolder> {

    private final List<Product> wishlistProducts = new ArrayList<>();

    public WishlistAdapter(List<Product> products) {
        if (products != null) {
            wishlistProducts.addAll(products);
        }
    }

    @NonNull
    @Override
    public WishlistViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product, parent, false);

        return new WishlistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull WishlistViewHolder holder, int position) {

        Product product = wishlistProducts.get(position);

        holder.title.setText(product.getTitle());
        holder.category.setText(product.getCategory());
        holder.condition.setText(product.getCondition());
        holder.price.setText(String.format(
                Locale.getDefault(), "₹%.2f", product.getPrice()));
    }

    @Override
    public int getItemCount() {
        return wishlistProducts.size();
    }

    public void updateWishlist(List<Product> products) {
        wishlistProducts.clear();

        if (products != null) {
            wishlistProducts.addAll(products);
        }

        notifyDataSetChanged();
    }

    static class WishlistViewHolder extends RecyclerView.ViewHolder {

        TextView title, category, condition, price;

        WishlistViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.tvProductTitle);
            category = itemView.findViewById(R.id.tvProductCategory);
            price = itemView.findViewById(R.id.tvProductPrice);
            condition = itemView.findViewById(R.id.tvProductCondition);
        }
    }
}
