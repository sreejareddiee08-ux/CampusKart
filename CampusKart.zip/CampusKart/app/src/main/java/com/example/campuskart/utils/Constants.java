package com.example.campuskart.utils;

public final class Constants {

    private Constants() {
        // Prevent object creation.
    }

    // App information
    public static final String APP_NAME = "CampusKart";

    // App colors
    public static final String COLOR_MAROON = "#800020";
    public static final String COLOR_DARK_MAROON = "#5A0016";
    public static final String COLOR_WHITE = "#FFFFFF";
    public static final String COLOR_BACKGROUND = "#FAF8F9";

    // Product categories
    public static final String[] PRODUCT_CATEGORIES = {
            "Books",
            "Electronics",
            "Fashion",
            "Accessories",
            "Stationery",
            "Hostel Essentials",
            "Other"
    };

    // Product conditions
    public static final String[] PRODUCT_CONDITIONS = {
            "New",
            "Like New",
            "Used"
    };

    // Intent keys
    public static final String EXTRA_PRODUCT_ID = "product_id";
    public static final String EXTRA_USER_ID = "user_id";
    public static final String EXTRA_CHAT_ID = "chat_id";

    // Validation constants
    public static final int MIN_PASSWORD_LENGTH = 8;
    public static final int MAX_PRODUCT_TITLE_LENGTH = 100;
    public static final int MAX_DESCRIPTION_LENGTH = 1000;
}
