
package com.example.campuskart.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.campuskart.R;
import com.example.campuskart.utils.ValidationUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName;
    private EditText etEmail;
    private EditText etStudentId;
    private EditText etDepartment;
    private EditText etPassword;
    private EditText etConfirmPassword;

    private Button btnRegister;
    private TextView tvGoToLogin;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        etName = findViewById(R.id.etRegisterName);
        etEmail = findViewById(R.id.etRegisterEmail);
        etStudentId = findViewById(R.id.etRegisterStudentId);
        etDepartment = findViewById(R.id.etRegisterDepartment);
        etPassword = findViewById(R.id.etRegisterPassword);
        etConfirmPassword = findViewById(R.id.etRegisterConfirmPassword);

        btnRegister = findViewById(R.id.btnRegister);
        tvGoToLogin = findViewById(R.id.tvGoToLogin);

        btnRegister.setOnClickListener(v -> registerUser());

        tvGoToLogin.setOnClickListener(v -> finish());
    }

    private void registerUser() {

        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String studentId = etStudentId.getText().toString().trim();
        String department = etDepartment.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();

        if (!ValidationUtils.isValidName(name)) {
            etName.setError("Enter your full name");
            etName.requestFocus();
            return;
        }

        if (!ValidationUtils.isValidEmail(email)) {
            etEmail.setError("Enter a valid email address");
            etEmail.requestFocus();
            return;
        }

        if (studentId.isEmpty()) {
            etStudentId.setError("Enter your student ID");
            etStudentId.requestFocus();
            return;
        }

        if (department.isEmpty()) {
            etDepartment.setError("Enter your department");
            etDepartment.requestFocus();
            return;
        }

        if (!ValidationUtils.isValidPassword(password)) {
            etPassword.setError(
                    "Password does not meet the requirements"
            );
            etPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            etConfirmPassword.requestFocus();
            return;
        }

        btnRegister.setEnabled(false);

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    btnRegister.setEnabled(true);

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();

                        if (user != null) {
                            user.sendEmailVerification()
                                    .addOnCompleteListener(
                                            verificationTask -> {
                                                if (verificationTask.isSuccessful()) {
                                                    Toast.makeText(
                                                            RegisterActivity.this,
                                                            "Account created! Please verify your email before logging in.",
                                                            Toast.LENGTH_LONG
                                                    ).show();
                                                } else {
                                                    Log.e(
                                                            "CampusKart",
                                                            "Verification email failed",
                                                            verificationTask.getException()
                                                    );

                                                    Toast.makeText(
                                                            RegisterActivity.this,
                                                            "Account created, but verification email could not be sent. You can request it again later.",
                                                            Toast.LENGTH_LONG
                                                    ).show();
                                                }

                                                mAuth.signOut();
                                                finish();
                                            }
                                    );
                        } else {
                            Toast.makeText(
                                    RegisterActivity.this,
                                    "Account created. Please log in.",
                                    Toast.LENGTH_LONG
                            ).show();
                            finish();
                        }

                    } else {
                        String errorMessage = "Registration failed. Please try again.";

                        if (task.getException() != null) {
                            Log.e(
                                    "CampusKart",
                                    "Registration failed",
                                    task.getException()
                            );

                            errorMessage = task.getException().getMessage();

                            if (errorMessage == null) {
                                errorMessage = "Registration failed. Please try again.";
                            }
                        }

                        Toast.makeText(
                                RegisterActivity.this,
                                errorMessage,
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }
}
