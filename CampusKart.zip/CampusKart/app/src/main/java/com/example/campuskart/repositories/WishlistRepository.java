package com.example.campuskart.repositories;

public class WishlistRepository {
}
