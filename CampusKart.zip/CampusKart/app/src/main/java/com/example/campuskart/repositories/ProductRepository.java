
package com.example.campuskart.repositories;

import android.util.Log;

import com.example.campuskart.models.Product;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ProductRepository {

    private static final String TAG = "ProductRepository";
    private final FirebaseFirestore db;

    public interface ProductCallback {
        void onSuccess(String productId);
        void onFailure(String error);
    }

    public ProductRepository() {
        db = FirebaseFirestore.getInstance();
    }

    public void saveProduct(
            Product product,
            String sellerId,
            ProductCallback callback
    ) {
        if (product == null || sellerId == null || sellerId.trim().isEmpty()) {
            if (callback != null) {
                callback.onFailure("Product or seller information is missing.");
            }
            return;
        }

        Map<String, Object> data = new HashMap<>();
        data.put("title", product.getTitle());
        data.put("description", product.getDescription());
        data.put("category", product.getCategory());
        data.put("condition", product.getCondition());
        data.put("sellerName", product.getSellerName());
        data.put("sellerEmail", product.getSellerEmail());
        data.put("sellerId", sellerId);
        data.put("price", product.getPrice());
        data.put("createdAt", FieldValue.serverTimestamp());

        db.collection("products")
                .add(data)
                .addOnSuccessListener(documentReference -> {
                    Log.d(TAG, "Product saved: " + documentReference.getId());

                    if (callback != null) {
                        callback.onSuccess(documentReference.getId());
                    }
                })
                .addOnFailureListener(exception -> {
                    Log.e(TAG, "Failed to save product", exception);

                    if (callback != null) {
                        String error = exception.getLocalizedMessage();

                        if (error == null || error.trim().isEmpty()) {
                            error = exception.getClass().getSimpleName();
                        }

                        callback.onFailure(error);
                    }
                });
    }
}
