package com.example.campuskart.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.adapters.WishlistAdapter;
import com.example.campuskart.models.Product;

import java.util.ArrayList;
import java.util.List;

public class WishlistActivity extends AppCompatActivity {

    private RecyclerView rvWishlist;
    private TextView tvEmptyWishlist;

    private WishlistAdapter wishlistAdapter;
    private final List<Product> wishlistProducts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        rvWishlist = findViewById(R.id.rvWishlist);
        tvEmptyWishlist = findViewById(R.id.tvEmptyWishlist);

        rvWishlist.setLayoutManager(
                new LinearLayoutManager(this));

        wishlistAdapter = new WishlistAdapter(wishlistProducts);
        rvWishlist.setAdapter(wishlistAdapter);

        updateEmptyState();
    }

    private void updateEmptyState() {
        boolean isEmpty = wishlistProducts.isEmpty();

        tvEmptyWishlist.setVisibility(
                isEmpty ? View.VISIBLE : View.GONE);

        rvWishlist.setVisibility(
                isEmpty ? View.GONE : View.VISIBLE);
    }
}
