package com.example.campuskart.activities;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.campuskart.R;

public class ReportActivity extends AppCompatActivity {

    private Spinner spReportReason;
    private EditText etReportDescription;
    private Button btnSubmitReport;

    private final String[] reportReasons = {
            "Select a reason",
            "Fraud or scam",
            "Incorrect product information",
            "Inappropriate content",
            "Prohibited item",
            "Suspicious seller",
            "Other"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        spReportReason = findViewById(R.id.spReportReason);
        etReportDescription =
                findViewById(R.id.etReportDescription);
        btnSubmitReport =
                findViewById(R.id.btnSubmitReport);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                reportReasons
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spReportReason.setAdapter(adapter);

        btnSubmitReport.setOnClickListener(view ->
                submitReport());
    }

    private void submitReport() {
        int selectedPosition =
                spReportReason.getSelectedItemPosition();

        String description =
                etReportDescription.getText().toString().trim();

        if (selectedPosition == 0) {
            Toast.makeText(
                    this,
                    "Please select a reason.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (description.isEmpty()) {
            etReportDescription.setError(
                    "Please explain the issue.");
            etReportDescription.requestFocus();
            return;
        }

        // Reporting is not connected to a database yet.
        Toast.makeText(
                this,
                "Report form validated. Submission will be connected later.",
                Toast.LENGTH_LONG
        ).show();
    }
}
