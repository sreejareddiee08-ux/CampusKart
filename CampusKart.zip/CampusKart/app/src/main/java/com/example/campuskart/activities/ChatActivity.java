package com.example.campuskart.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.adapters.MessageAdapter;
import com.example.campuskart.models.Message;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private TextView tvChatTitle;
    private TextView tvChatSubtitle;
    private EditText etMessage;
    private Button btnSendMessage;
    private RecyclerView rvMessages;

    private MessageAdapter messageAdapter;
    private final List<Message> messages = new ArrayList<>();

    // Temporary identifier until real authentication is connected.
    private final String currentUserId = "current_user";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        tvChatTitle = findViewById(R.id.tvChatTitle);
        tvChatSubtitle = findViewById(R.id.tvChatSubtitle);
        etMessage = findViewById(R.id.etMessage);
        btnSendMessage = findViewById(R.id.btnSendMessage);
        rvMessages = findViewById(R.id.rvMessages);

        tvChatTitle.setText("CampusKart Chat");
        tvChatSubtitle.setText(
                "Discuss the product with the seller");

        rvMessages.setLayoutManager(
                new LinearLayoutManager(this));

        messageAdapter = new MessageAdapter(
                messages, currentUserId);

        rvMessages.setAdapter(messageAdapter);

        btnSendMessage.setOnClickListener(view ->
                sendMessage());
    }

    private void sendMessage() {
        String messageText =
                etMessage.getText().toString().trim();

        if (messageText.isEmpty()) {
            etMessage.setError("Enter a message");
            return;
        }

        // Messages are not saved yet.
        // Firebase messaging will be added later.
        Toast.makeText(
                this,
                "Messaging will be connected to the backend later.",
                Toast.LENGTH_SHORT
        ).show();

        etMessage.setText("");
    }
}
