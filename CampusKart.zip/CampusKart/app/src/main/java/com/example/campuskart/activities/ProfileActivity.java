package com.example.campuskart.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.campuskart.R;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvProfileInitial;
    private TextView tvProfileName;
    private TextView tvProfileEmail;
    private TextView tvProfileStudentId;
    private TextView tvProfileDepartment;

    private Button btnListings;
    private Button btnWishlist;
    private Button btnChats;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        tvProfileInitial = findViewById(R.id.tvProfileInitial);
        tvProfileName = findViewById(R.id.tvProfileName);
        tvProfileEmail = findViewById(R.id.tvProfileEmail);
        tvProfileStudentId = findViewById(R.id.tvProfileStudentId);
        tvProfileDepartment = findViewById(R.id.tvProfileDepartment);

        btnListings = findViewById(R.id.btnProfileListings);
        btnWishlist = findViewById(R.id.btnProfileWishlist);
        btnChats = findViewById(R.id.btnProfileChats);
        btnLogout = findViewById(R.id.btnProfileLogout);

        // Temporary placeholder profile until account data is connected.
        tvProfileName.setText("Student Name");
        tvProfileEmail.setText("student@example.com");
        tvProfileStudentId.setText("Student ID: Not available");
        tvProfileDepartment.setText("Department: Not available");
        tvProfileInitial.setText("S");

        btnListings.setOnClickListener(view ->
                startActivity(new Intent(
                        this, MyListingsActivity.class)));

        btnWishlist.setOnClickListener(view ->
                startActivity(new Intent(
                        this, WishlistActivity.class)));

        btnChats.setOnClickListener(view ->
                startActivity(new Intent(
                        this, ChatActivity.class)));

        btnLogout.setOnClickListener(view -> {
            Toast.makeText(
                    this,
                    "Logout will be connected to authentication later.",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}
