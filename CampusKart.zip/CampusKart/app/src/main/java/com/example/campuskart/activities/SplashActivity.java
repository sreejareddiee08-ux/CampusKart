package com.example.campuskart.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.campuskart.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
    }
}
