
package com.example.campuskart.models;

public class User {

    private String userId;
    private String fullName;
    private String email;
    private String department;
    private String studentId;

    public User() {
        // Empty constructor
    }

    public User(String userId, String fullName, String email,
                String department, String studentId) {
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.department = department;
        this.studentId = studentId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
}
