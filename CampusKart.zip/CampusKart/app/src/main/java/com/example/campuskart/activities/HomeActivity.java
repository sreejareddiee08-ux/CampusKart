
package com.example.campuskart.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.adapters.CategoryAdapter;
import com.example.campuskart.adapters.ProductAdapter;
import com.example.campuskart.models.Category;
import com.example.campuskart.models.Product;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private EditText etSearchProducts;
    private TextView tvHomeProfile;
    private Button btnAddProduct;
    private RecyclerView rvCategories;
    private RecyclerView rvProducts;

    private CategoryAdapter categoryAdapter;
    private ProductAdapter productAdapter;

    private final List<Category> categories = new ArrayList<>();
    private final List<Product> products = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        etSearchProducts = findViewById(R.id.etSearchProducts);
        tvHomeProfile = findViewById(R.id.tvHomeProfile);
        btnAddProduct = findViewById(R.id.btnAddProduct);
        rvCategories = findViewById(R.id.rvCategories);
        rvProducts = findViewById(R.id.rvProducts);

        setupCategories();
        setupProducts();

        tvHomeProfile.setOnClickListener(view ->
                startActivity(new Intent(
                        HomeActivity.this,
                        ProfileActivity.class
                ))
        );

        btnAddProduct.setOnClickListener(view ->
                startActivity(new Intent(
                        HomeActivity.this,
                        AddProductActivity.class
                ))
        );
    }

    private void setupCategories() {
        categories.clear();

        String[] categoryNames = {
                "Books",
                "Electronics",
                "Fashion",
                "Accessories",
                "Stationery",
                "Hostel Essentials",
                "Other"
        };

        for (int i = 0; i < categoryNames.length; i++) {
            categories.add(new Category(
                    String.valueOf(i + 1),
                    categoryNames[i],
                    0
            ));
        }

        rvCategories.setLayoutManager(
                new LinearLayoutManager(
                        this,
                        LinearLayoutManager.HORIZONTAL,
                        false
                )
        );

        categoryAdapter = new CategoryAdapter(categories);
        rvCategories.setAdapter(categoryAdapter);
    }

    private void setupProducts() {
        rvProducts.setLayoutManager(
                new LinearLayoutManager(this)
        );

        productAdapter = new ProductAdapter(products);
        rvProducts.setAdapter(productAdapter);
    }
}
