package com.example.campuskart.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.adapters.ProductAdapter;
import com.example.campuskart.models.Product;

import java.util.ArrayList;
import java.util.List;

public class MyListingsActivity extends AppCompatActivity {

    private RecyclerView rvMyListings;
    private TextView tvNoListings;
    private Button btnCreateListing;

    private ProductAdapter productAdapter;
    private final List<Product> myProducts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_listings);

        rvMyListings = findViewById(R.id.rvMyListings);
        tvNoListings = findViewById(R.id.tvNoListings);
        btnCreateListing = findViewById(R.id.btnCreateListing);

        rvMyListings.setLayoutManager(
                new LinearLayoutManager(this));

        productAdapter = new ProductAdapter(myProducts);
        rvMyListings.setAdapter(productAdapter);

        updateEmptyState();

        btnCreateListing.setOnClickListener(view -> {
            Intent intent = new Intent(
                    MyListingsActivity.this,
                    AddProductActivity.class
            );
            startActivity(intent);
        });
    }

    private void updateEmptyState() {
        boolean isEmpty = myProducts.isEmpty();

        tvNoListings.setVisibility(
                isEmpty ? View.VISIBLE : View.GONE);

        rvMyListings.setVisibility(
                isEmpty ? View.GONE : View.VISIBLE);
    }

    private void showMessage(String message) {
        Toast.makeText(
                this, message, Toast.LENGTH_SHORT).show();
    }
}
