
package com.example.campuskart.models;

public class Chat {

    private String chatId;
    private String buyerId;
    private String sellerId;
    private String productId;
    private String lastMessage;
    private long lastMessageTime;

    public Chat() {
    }

    public Chat(String chatId, String buyerId, String sellerId,
                String productId, String lastMessage, long lastMessageTime) {
        this.chatId = chatId;
        this.buyerId = buyerId;
        this.sellerId = sellerId;
        this.productId = productId;
        this.lastMessage = lastMessage;
        this.lastMessageTime = lastMessageTime;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }

    public long getLastMessageTime() {
        return lastMessageTime;
    }

    public void setLastMessageTime(long lastMessageTime) {
        this.lastMessageTime = lastMessageTime;
    }
}
