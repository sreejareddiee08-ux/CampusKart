package com.example.campuskart.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.adapters.ChatAdapter;
import com.example.campuskart.models.Chat;

import java.util.ArrayList;
import java.util.List;

public class ChatListActivity extends AppCompatActivity {

    private RecyclerView rvChatList;
    private TextView tvEmptyChats;

    private ChatAdapter chatAdapter;
    private final List<Chat> chatList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        rvChatList = findViewById(R.id.rvChatList);
        tvEmptyChats = findViewById(R.id.tvEmptyChats);

        rvChatList.setLayoutManager(
                new LinearLayoutManager(this));

        chatAdapter = new ChatAdapter(chatList);
        rvChatList.setAdapter(chatAdapter);

        updateEmptyState();
    }

    private void updateEmptyState() {
        boolean isEmpty = chatList.isEmpty();

        tvEmptyChats.setVisibility(
                isEmpty ? View.VISIBLE : View.GONE);

        rvChatList.setVisibility(
                isEmpty ? View.GONE : View.VISIBLE);
    }
}
