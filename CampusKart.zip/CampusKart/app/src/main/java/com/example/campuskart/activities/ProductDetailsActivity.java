package com.example.campuskart.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.campuskart.R;

public class ProductDetailsActivity extends AppCompatActivity {

    private ImageView ivProductImage;
    private TextView tvTitle;
    private TextView tvPrice;
    private TextView tvCategory;
    private TextView tvCondition;
    private TextView tvDescription;
    private TextView tvSellerName;

    private Button btnContactSeller;
    private Button btnAddToWishlist;
    private Button btnReportProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        ivProductImage = findViewById(R.id.ivProductImage);
        tvTitle = findViewById(R.id.tvDetailProductTitle);
        tvPrice = findViewById(R.id.tvDetailProductPrice);
        tvCategory = findViewById(R.id.tvDetailProductCategory);
        tvCondition = findViewById(R.id.tvDetailProductCondition);
        tvDescription = findViewById(R.id.tvDetailProductDescription);
        tvSellerName = findViewById(R.id.tvDetailSellerName);

        btnContactSeller = findViewById(R.id.btnContactSeller);
        btnAddToWishlist = findViewById(R.id.btnAddToWishlist);
        btnReportProduct = findViewById(R.id.btnReportProduct);

        // Temporary placeholder content until product data is connected.
        tvTitle.setText("Product title");
        tvPrice.setText("₹0.00");
        tvCategory.setText("Category");
        tvCondition.setText("Condition");
        tvDescription.setText(
                "Product description will appear here.");
        tvSellerName.setText("Seller information will appear here.");

        btnContactSeller.setOnClickListener(view ->
                showMessage("Messaging will be connected later."));

        btnAddToWishlist.setOnClickListener(view ->
                showMessage("Wishlist functionality will be added later."));

        btnReportProduct.setOnClickListener(view ->
                showMessage("Product reporting will be added later."));
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
