
package com.example.campuskart.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.models.Message;

import java.util.ArrayList;
import java.util.List;

public class MessageAdapter
        extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {

    private final List<Message> messageList = new ArrayList<>();
    private final String currentUserId;

    public MessageAdapter(List<Message> messages, String currentUserId) {
        if (messages != null) {
            messageList.addAll(messages);
        }

        this.currentUserId = currentUserId;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message, parent, false);

        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull MessageViewHolder holder, int position) {

        Message message = messageList.get(position);

        holder.messageText.setText(message.getMessageText());

        boolean isCurrentUserMessage =
                currentUserId != null
                        && currentUserId.equals(message.getSenderId());

        holder.senderLabel.setText(
                isCurrentUserMessage ? "You" : "Other user");
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    public void updateMessages(List<Message> messages) {
        messageList.clear();

        if (messages != null) {
            messageList.addAll(messages);
        }

        notifyDataSetChanged();
    }

    static class MessageViewHolder extends RecyclerView.ViewHolder {

        TextView messageText;
        TextView senderLabel;

        MessageViewHolder(@NonNull View itemView) {
            super(itemView);

            messageText = itemView.findViewById(R.id.tvMessageText);
            senderLabel = itemView.findViewById(R.id.tvSenderLabel);
        }
    }
}
