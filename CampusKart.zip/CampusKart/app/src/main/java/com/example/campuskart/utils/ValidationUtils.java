
package com.example.campuskart.utils;

import android.util.Patterns;

public final class ValidationUtils {

    private ValidationUtils() {
        // Prevent object creation
    }

    public static boolean isValidName(String name) {
        return name != null && !name.trim().isEmpty()
                && name.trim().length() >= 2;
    }

    public static boolean isValidEmail(String email) {
        return email != null
                && Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null
                && password.length() >= Constants.MIN_PASSWORD_LENGTH;
    }

    public static boolean isValidProductTitle(String title) {
        return title != null
                && !title.trim().isEmpty()
                && title.trim().length() <= Constants.MAX_PRODUCT_TITLE_LENGTH;
    }

    public static boolean isValidDescription(String description) {
        return description != null
                && !description.trim().isEmpty()
                && description.trim().length() <= Constants.MAX_DESCRIPTION_LENGTH;
    }

    public static boolean isValidPrice(String priceText) {
        if (priceText == null || priceText.trim().isEmpty()) {
            return false;
        }

        try {
            double price = Double.parseDouble(priceText.trim());
            return Double.isFinite(price) && price >= 0;
        } catch (NumberFormatException exception) {
            return false;
        }
    }

    public static boolean isNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
