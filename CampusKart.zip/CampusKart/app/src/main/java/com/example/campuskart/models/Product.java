
package com.example.campuskart.models;

public class Product {

    private String productId;
    private String title;
    private String description;
    private String category;
    private String condition;
    private String sellerName;
    private String sellerEmail;
    private double price;

    public Product() {
        // Empty constructor
    }

    public Product(String productId, String title, String description,
                   String category, String condition, String sellerName,
                   String sellerEmail, double price) {
        this.productId = productId;
        this.title = title;
        this.description = description;
        this.category = category;
        this.condition = condition;
        this.sellerName = sellerName;
        this.sellerEmail = sellerEmail;
        this.price = price;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSellerEmail() {
        return sellerEmail;
    }

    public void setSellerEmail(String sellerEmail) {
        this.sellerEmail = sellerEmail;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
