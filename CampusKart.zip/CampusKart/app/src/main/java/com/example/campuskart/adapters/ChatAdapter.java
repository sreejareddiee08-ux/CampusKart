
package com.example.campuskart.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campuskart.R;
import com.example.campuskart.models.Chat;

import java.util.ArrayList;
import java.util.List;

public class ChatAdapter
        extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private final List<Chat> chatList = new ArrayList<>();

    public ChatAdapter(List<Chat> chats) {
        if (chats != null) {
            chatList.addAll(chats);
        }
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_chat, parent, false);

        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ChatViewHolder holder, int position) {

        Chat chat = chatList.get(position);

        holder.lastMessage.setText(
                chat.getLastMessage() == null
                        ? "Start a conversation"
                        : chat.getLastMessage());

        // Participant names will be connected when user data is available.
        holder.participantName.setText("CampusKart chat");
    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public void updateChats(List<Chat> chats) {
        chatList.clear();

        if (chats != null) {
            chatList.addAll(chats);
        }

        notifyDataSetChanged();
    }

    static class ChatViewHolder extends RecyclerView.ViewHolder {

        TextView participantName;
        TextView lastMessage;

        ChatViewHolder(@NonNull View itemView) {
            super(itemView);

            participantName =
                    itemView.findViewById(R.id.tvChatParticipant);
            lastMessage =
                    itemView.findViewById(R.id.tvLastMessage);
        }
    }
}
